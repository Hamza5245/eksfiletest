const express = require('express')
const cors=require('cors')
const cookieParser = require('cookie-parser')
const requestIp = require('request-ip');
const bodyParser = require("body-parser");
const http = require('http');
const mongoose = require("mongoose")
const socketIO = require('socket.io');
const { Server } = require('socket.io');
const bookCategory = require('./socket/bookCategorySocket.js');
const acceptBookCategory = require('./socket/acceptBookSocket.js');
const book = require('./socket/bookSocket.js');


const app=express()

// const server = require('http').createServer(app)
// const io = require('socket.io').Server()


// middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(cookieParser())
app.use(requestIp.mw());
app.use(bodyParser.json());






mongoose.set('strictQuery', true);
mongoose.connect('mongodb://127.0.0.1/almumtaz')
  .then(() => console.log('Connection Successfull!'))
  .catch((err)=>console.log(err));




const connectMongoDB = async() => {
    try{
        const conn = await mongoose.connect('mongodb://127.0.0.1/almumtaz')
        console.log("Successfully Connected")
    }catch(error){
        console.log('Error in connecting DataBase ${error}.bgRed.white')
    }
}

connectMongoDB()





// const server = http.createServer(app);
// const io = socketIO(server);


// routers
const sellerRouter = require('./routes/sellerRoutes.js')
const verifyRouter = require('./routes/verifyRoutes.js')
const sliderRouter = require('./routes/sliderRoutes.js')
const acceptBookRouter = require('./routes/acceptBookRoutes.js')
const bookRouter = require('./routes/bookRoutes.js')
const quotationRouter = require('./routes/quotationRoutes.js')
const notificationRouter = require('./routes/notificationRoutes.js')
const ratingRouter = require('./routes/ratingRoutes.js')
const serviceRouter = require('./routes/serviceRoutes.js')
const categoryRouter = require('./routes/categoryRoutes.js')
const subCategoryRouter = require('./routes/subCategoryRoutes.js')
const countryRouter = require('./routes/countryRoutes.js')
const cityRouter = require('./routes/cityRoutes.js')
const taxRouter = require('./routes/taxRoutes.js')
const userRouter = require('./routes/userRoutes.js')
const loginRouter = require('./routes/loginRoutes.js');
const { url } = require('./config/dbConfig.js');










app.use('/almumtaz/seller',sellerRouter)
app.use('/almumtaz/verify',verifyRouter)
app.use('/almumtaz/slider',sliderRouter)
app.use('/almumtaz/acceptBook',acceptBookRouter)
app.use('/almumtaz/book',bookRouter)
app.use('/almumtaz/quotation',quotationRouter)
app.use('/almumtaz/notification',notificationRouter)
app.use('/almumtaz/rating',ratingRouter)
app.use('/almumtaz/category',categoryRouter)
app.use('/almumtaz/subCategory',subCategoryRouter)
app.use('/almumtaz/country',countryRouter)
app.use('/almumtaz/city',cityRouter)
app.use('/almumtaz/tax',taxRouter)
app.use('/almumtaz/user',userRouter)
app.use('/almumtaz/service',serviceRouter)
app.use('/almumtaz/login',loginRouter)






app.use(express.static(__dirname + '/Images'))




// testing
app.get('/',(req,res)=>{
    res.json({ message:'Success'})
})


const PORT=process.env.PORT || 8000 
 
app.listen(PORT,()=>{
    console.log(`Server listening on port ${PORT}`)
})

const server = require('http').createServer(app)
server.listen(8001)

const io = new Server(server, {
    cors: {
        cors: true,
    }
})


// const io = new Server()


bookCategory(io) 
acceptBookCategory(io) 
book(io) 