const mongoose = require('mongoose');

const sellerSchema = new mongoose.Schema({
    firstName: {
        type: String,
        allowNull: true,
    },
    lastName: {
        type: String,
        allowNull: true,
    },
    token: {
        type: String,
        allowNull: true,
    },
    gender: {
        type: String,
        allowNull: true,
    },
    email: {
        type: String,
        allowNull: true,
    },
    phone: {
        type: String,
        allowNull: true,
    },
    password: {
        type: String,
        allowNull: true,
    },
    idCardNumber: {
        type: String,
        allowNull: true,
    },
    serviceId: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Service',
    },
    categoryId: {
        type: mongoose.Schema.Types.ObjectId,
        ref:'Category',
    },
    image: {
        type: String,
        allowNull: true,
    },
    frontImage: {
        type: String,
        allowNull: true,
    },
    backImage: {
        type: String,
        allowNull: true,
    },
    address: {
        type: String,
        allowNull: true,
    },
    country: {
        type: String,
        allowNull: true,
    },
    averageRating: {
        type: String,
        allowNull: true,
    },
    lat: {
        type: String,
        allowNull: true,
    },
    lng: {
        type: String,
        allowNull: true,
    },
    verify: {
        type: Boolean,
        allowNull: true,
        default:false
    },
    block: {
        type: Boolean,
        allowNull: true,
    },
},{timestamps:true});



const Seller = mongoose.model('Seller', sellerSchema);

module.exports = Seller;
