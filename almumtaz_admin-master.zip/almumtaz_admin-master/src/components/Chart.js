// import React from 'react';
// import { Line } from '@ant-design/charts';

// const MyLineChart = () => {
//   const data = [
//     { year: '2018', sales: 1000, profit: 200, type: 'Sales' },
//     { year: '2019', sales: 2000, profit: 400, type: 'Sales' },
//     { year: '2020', sales: 3000, profit: 600, type: 'Sales' },
//     { year: '2021', sales: 5000, profit: 800, type: 'Sales' },
//     { year: '2018', sales: 2000, profit: 100, type: 'Profit' },
//     { year: '2019', sales: 1400, profit: 300, type: 'Profit' },
//     { year: '2020', sales: 2100, profit: 500, type: 'Profit' },
//     { year: '2021', sales: 3200, profit: 700, type: 'Profit' },
//   ];

//   const config = {
//     data: data,
//     xField: 'year',
//     yField: ['sales', 'profit'],
//     seriesField: 'type',
//     height: 400,
//     style: {
//       background: { fill: '#f0f2f5' }, // Background color of the chart area
//     },
//     lineStyle: [
//       // Customize line styles
//       { stroke: '#1890ff', lineWidth: 4 }, // Sales line
//       { stroke: '#2fc25b', lineWidth: 4 }, // Profit line
//     ],
//   };

//   return <Line {...config} />;
// };

// export default MyLineChart;
