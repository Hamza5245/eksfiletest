// const  ApiUrl = 'http://5.78.112.149:8000/almumtaz'
const  ApiUrl = 'http://37.27.18.90:8000/almumtaz'

export default ApiUrl